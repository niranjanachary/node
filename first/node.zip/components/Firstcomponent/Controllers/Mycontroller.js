var Mycontroller = {};
Mycontroller.index = function(req,res) {
    var data = {'ejs_page':'layout/home'};
    res.render('layout/index',data);
};
Mycontroller.dashboard = async  function(req,res) {
    if(req.session.user){
        res.json({'status':true,'message':'Show dasboard','user':req.session.user});
    } else {
        res.json({'status':false,'message':'Redirect to login page'});
    }
}

module.exports = Mycontroller;
// global.controllers['mycontroller'] = mycontroller;