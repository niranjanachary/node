var express = require('express');
var app = express();

//Middleware function to log request protocol
app.use('/', function(req, res, next) {
	res.locals.user = null;
	if(req.session.user){
        res.locals.user = req.session.user;
    }

	// // override logic
    // var _render = res.render;
    // res.render = function( view, options, fn ) {
	// 	//get theme from db
    //     _.extend( options, {session: true} );
    //     _render.call( this, view, options, fn );
	// }
	
	// console.log(util.inspect(req.method));
	// res.send('Hello browser, here is my data: '+ util.inspect(req));
	// console.log("A request for middleware register received at " + Date.now());
	next();
});

app.use( '/admin/*', function( req, res, next ) {
	// // override logic
    var _render = res.render;
    res.render = function( view, options, fn ) {
		//get theme from db
		var _view = view;
		view = 'admin/index';
		options.ejs_page = _view;
        // _.extend( options, {session: true} );
        _render.call( this, view, options, fn );
	}
	next();
});
module.exports = app;